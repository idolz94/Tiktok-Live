"use client";

import { useState } from "react";
import { useAuth } from "../hooks/useAuth";

type Mode = "login" | "register";

export default function AuthScreen() {
  const { login, register } = useAuth();

  const [mode, setMode] = useState<Mode>("login");
  const [phone, setPhone] = useState("0816507286");
  const [password, setPassword] = useState("123456");
  const [remember, setRemember] = useState(true);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  const isLogin = mode === "login";

  function submit() {
    const result = isLogin ? login(phone, password) : register(phone, password);

    if (!result.ok) {
      window.alert(`${isLogin ? "Đăng nhập thất bại" : "Đăng ký thất bại"}\n${result.message || ""}`);
    }
  }

  function toggleMode() {
    setMode((current) => (current === "login" ? "register" : "login"));
  }

  return (
    <main className="auth-background">
      <div className="auth-safe">
        <div className="auth-scroll-content">
          <img src="/assets/login-banner.png" alt="Flive banner" className="auth-banner" />

          <section className="auth-card">
            <h1 className="auth-heading">Trải nghiệm miễn phí</h1>

            <button className="register-button" onClick={() => setMode("register")} type="button">
              ĐĂNG KÝ NGAY
            </button>

            <div className="divider-row">
              <span className="divider" />
              <span className="divider-text">hoặc đăng nhập</span>
              <span className="divider" />
            </div>

            <label className="auth-label">Số điện thoại</label>
            <div className="auth-input-wrap">
              <input
                value={phone}
                onChange={(event) => setPhone(event.target.value)}
                inputMode="tel"
                autoCapitalize="none"
                autoCorrect="off"
                placeholder="Nhập số điện thoại"
                className="auth-input"
              />
              <span className="valid-icon">✓</span>
            </div>

            <label className="auth-label">Mật khẩu</label>
            <div className="auth-input-wrap">
              <input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                type={isPasswordVisible ? "text" : "password"}
                placeholder="Nhập mật khẩu"
                className="auth-input"
              />

              <button
                className="eye-icon"
                onClick={() => setIsPasswordVisible((value) => !value)}
                type="button"
              >
                {isPasswordVisible ? "◉" : "◉̸"}
              </button>

              <span className="valid-icon">✓</span>
            </div>

            <button className="remember-row" onClick={() => setRemember((value) => !value)} type="button">
              <span className={`checkbox ${remember ? "active" : ""}`}>{remember ? "✓" : ""}</span>
              <span className="remember-text">Ghi nhớ đăng nhập</span>
            </button>

            <button className="login-button" onClick={submit} type="button">
              {isLogin ? "ĐĂNG NHẬP" : "TẠO TÀI KHOẢN"}
            </button>

            <button className="forgot-button" type="button">Quên mật khẩu</button>

            <div className="divider-row consult">
              <span className="divider" />
              <span className="consult-text">Tư vấn</span>
              <span className="divider" />
            </div>

            <div className="social-row">
              <button className="social-button" type="button">
                <img src="/assets/login-facebook.png" alt="Facebook" />
              </button>

              <button className="social-button" type="button">
                <img src="/assets/login-zalo.png" alt="Zalo" />
              </button>

              <button className="social-button" type="button">
                <img src="/assets/login-tiktok.png" alt="TikTok" />
              </button>
            </div>

            <button className="switch-mode-text" onClick={toggleMode} type="button">
              {isLogin ? "Chưa có tài khoản? Đăng ký" : "Đã có tài khoản? Đăng nhập"}
            </button>
          </section>
        </div>
      </div>
    </main>
  );
}
