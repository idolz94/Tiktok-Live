"use client";

import { LiveHistoryItem } from "@/features/tiktok-live/types";
import CommentCard from "../../../components/CommentCard";
import OrderCard from "../../../components/OrderCard";
import OrderFilterBar from "../../../components/OrderFilterBar";
import { LiveComment, LiveTab, Order, OrderFilter, OrderProduct, TopTab } from "../../../types";
import PlaceholderView from "./PlaceholderView";
import SectionHeader from "./SectionHeader";
import StatsRow from "./StatsRow";

export default function HomeView({
  topTab,
  liveTab,
  comments,
  orders,
  filteredOrders,
  orderFilter,
  orderSearchText,
  buyingCount,
  unpaidOrders,
  paidOrders,
  draftOrders,
  confirmedOrders,
  orderProductCount,
  onChangeLiveTab,
  onChangeOrderFilter,
  onChangeOrderSearchText,
  onClearComments,
  onClearOrders,
  onCreateOrderFromComment,
  onUpdateOrder,
  onDeleteOrder,
  onAddProductToOrder,
  onToggleDeposit,
  onConfirmOrder,
  onOpenOrderOverview,
  liveHistory,
}: {
  topTab: TopTab;
  liveTab: LiveTab;
  comments: LiveComment[];
  orders: Order[];
  filteredOrders: Order[];
  orderFilter: OrderFilter;
  orderSearchText: string;
  buyingCount: number;
  unpaidOrders: number;
  paidOrders: number;
  draftOrders: number;
  confirmedOrders: number;
  orderProductCount: number;
  onChangeLiveTab: (tab: LiveTab) => void;
  onChangeOrderFilter: (filter: OrderFilter) => void;
  onChangeOrderSearchText: (value: string) => void;
  onClearComments: () => void;
  onClearOrders: () => void;
  onCreateOrderFromComment: (item: LiveComment) => void;
  onUpdateOrder: (id: string, field: keyof Order, value: string) => void;
  onDeleteOrder: (id: string) => void;
  onAddProductToOrder: (orderId: string, product: OrderProduct) => void;
  onToggleDeposit: (orderId: string) => void;
  onConfirmOrder: (orderId: string) => void;
  onOpenOrderOverview: (orderId: string) => void;
  liveHistory: LiveHistoryItem[]
}) {
  console.log("liveHistory vaof o :",liveHistory);
  if (topTab === "history") {
    return (
      <div className="content-area">
        <PlaceholderView
          liveHistory={liveHistory}
        />
      </div>
    );
  }

  return (
    <>
      <div className="live-tabs">
        <button
          className={`live-tab ${liveTab === "live" ? "active" : ""}`}
          onClick={() => onChangeLiveTab("live")}
          type="button"
        >
          ♪ LIVE
        </button>

        <button
          className={`live-tab ${liveTab === "orders" ? "active" : ""}`}
          onClick={() => onChangeLiveTab("orders")}
          type="button"
        >
          ▧ Đơn đã tạo
        </button>
      </div>

      {liveTab === "live" ? (
        <div className="list-content scroll-panel">
          <StatsRow commentsCount={comments.length} buyingCount={buyingCount} ordersCount={orders.length} />
          <SectionHeader title="Comment realtime" actionText="Xóa comment" onAction={onClearComments} />

          {comments.length === 0 ? (
            <div className="empty">
              <p className="empty-text">Chưa có comment. Hãy chạy Python socket, app sẽ tự kết nối.</p>
            </div>
          ) : (
            comments.map((item) => (
              <CommentCard key={item.id} item={item} onCreateOrder={onCreateOrderFromComment} />
            ))
          )}
        </div>
      ) : (
        <div className="order-list-content scroll-panel">
          <OrderFilterBar
            searchText={orderSearchText}
            onChangeSearch={onChangeOrderSearchText}
            activeFilter={orderFilter}
            onChangeFilter={onChangeOrderFilter}
            productCount={orderProductCount}
            unpaidCount={unpaidOrders}
            paidCount={paidOrders}
            draftCount={draftOrders}
            confirmedCount={confirmedOrders}
          />

          <div className="order-list-inner">
            <SectionHeader title="Đơn đã tạo" actionText="Xóa đơn" onAction={onClearOrders} />

            {filteredOrders.length === 0 ? (
              <div className="empty">
                <p className="empty-text">Chưa có đơn nào.</p>
              </div>
            ) : (
              filteredOrders.map((item) => (
                <OrderCard
                  key={item.id}
                  item={item}
                  onUpdate={onUpdateOrder}
                  onDelete={onDeleteOrder}
                  onAddProduct={onAddProductToOrder}
                  onToggleDeposit={onToggleDeposit}
                  onConfirmOrder={onConfirmOrder}
                  onOpenOverview={onOpenOrderOverview}
                />
              ))
            )}
          </div>
        </div>
      )}
    </>
  );
}
