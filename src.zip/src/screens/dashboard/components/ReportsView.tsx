"use client";

import { formatMoneyFromK } from "../../../utils/order";

export default function ReportsView({
  commentsCount,
  buyingCount,
  ordersCount,
  totalRevenue,
}: {
  commentsCount: number;
  buyingCount: number;
  ordersCount: number;
  totalRevenue: number;
}) {
  return (
    <div className="list-content scroll-panel">
      <div className="page-header">
        <h1 className="page-title">Báo cáo</h1>
        <p className="page-subtitle">Thống kê nhanh từ comment và đơn đã tạo</p>
      </div>

      <div className="report-grid">
        <div className="report-card">
          <strong className="report-number">{commentsCount}</strong>
          <span className="report-label">Tổng comment</span>
        </div>

        <div className="report-card">
          <strong className="report-number">{buyingCount}</strong>
          <span className="report-label">Comment có thể chốt</span>
        </div>

        <div className="report-card">
          <strong className="report-number">{ordersCount}</strong>
          <span className="report-label">Tổng đơn</span>
        </div>

        <div className="report-card">
          <strong className="report-number small">{formatMoneyFromK(totalRevenue)}</strong>
          <span className="report-label">Doanh thu tạm tính</span>
        </div>
      </div>
    </div>
  );
}
