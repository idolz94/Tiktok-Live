"use client";

import { useEffect, useState } from "react";
import { DEFAULT_WS_URL } from "../../../constants/config";

function normalizeTikTokUsername(value: string) {
  const cleanValue = String(value || "").trim();
  if (!cleanValue) return "";
  return cleanValue.startsWith("@") ? cleanValue : `@${cleanValue}`;
}

export default function SettingsView({
  username,
  tiktokUsername,
  isConnected,
  status,
  onChangeTikTokUsername,
  onLogout,
}: {
  username?: string;
  tiktokUsername: string;
  isConnected: boolean;
  status: string;
  onChangeTikTokUsername: (username: string) => void;
  onLogout: () => void;
}) {
  const [inputUsername, setInputUsername] = useState(tiktokUsername);

  useEffect(() => {
    setInputUsername(tiktokUsername);
  }, [tiktokUsername]);

  function submitTikTokUsername() {
    const nextUsername = normalizeTikTokUsername(inputUsername);
    if (!nextUsername) return;
    onChangeTikTokUsername(nextUsername);
  }

  return (
    <div className="list-content scroll-panel">
      <div className="page-header">
        <h1 className="page-title">Cài đặt</h1>
        <p className="page-subtitle">Thông tin kết nối và tài khoản</p>
      </div>

      <div className="setting-card">
        <span className="setting-label">Tài khoản</span>
        <strong className="setting-value">{username}</strong>
      </div>

      <div className="setting-card">
        <span className="setting-label">TikTok LIVE username của app này</span>

        <div className="setting-input-row">
          <input
            value={inputUsername}
            onChange={(event) => setInputUsername(event.target.value)}
            autoCapitalize="none"
            autoCorrect="off"
            placeholder="@username"
            className="setting-input"
          />

          <button className="setting-update-btn" onClick={submitTikTokUsername} type="button">
            Subscribe
          </button>
        </div>

        <p className="setting-helper-text">
          Mỗi web app có thể nhập username riêng. Python sẽ chỉ gửi comment của username này về web app này.
        </p>
      </div>

      <div className="setting-card">
        <span className="setting-label">WebSocket URL</span>
        <strong className="setting-value">{DEFAULT_WS_URL}</strong>
      </div>

      <div className="setting-card">
        <span className="setting-label">Trạng thái</span>
        <strong className={`setting-value ${isConnected ? "online" : "offline"}`}>{status}</strong>
      </div>

      <button className="logout-full-btn" onClick={onLogout} type="button">
        Đăng xuất
      </button>
    </div>
  );
}
