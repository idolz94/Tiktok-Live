"use client";

import { TopTab } from "../../../types";

export default function TopSegmentTabs({
  activeTab,
  onChange,
}: {
  activeTab: TopTab;
  onChange: (tab: TopTab) => void;
}) {
  return (
    <div className="top-segment">
      <button
        className={`top-segment-item ${activeTab === "connect" ? "active" : ""}`}
        onClick={() => onChange("connect")}
        type="button"
      >
        KẾT NỐI LIVE
      </button>

      <button
        className={`top-segment-item ${activeTab === "history" ? "active" : ""}`}
        onClick={() => onChange("history")}
        type="button"
      >
        LỊCH SỬ
      </button>
    </div>
  );
}
