"use client";

import { CustomerSummary } from "../types";

export default function CustomersView({ customers }: { customers: CustomerSummary[] }) {
  return (
    <div className="list-content scroll-panel">
      <div className="page-header">
        <h1 className="page-title">Khách hàng</h1>
        <p className="page-subtitle">Tổng hợp khách đã comment hoặc đã tạo đơn</p>
      </div>

      {customers.length === 0 ? (
        <div className="empty">
          <p className="empty-text">Chưa có khách hàng. Khi có comment, khách sẽ xuất hiện ở đây.</p>
        </div>
      ) : (
        customers.map((item) => (
          <article key={item.username} className="customer-card">
            <div className="customer-avatar">{item.username.charAt(0).toUpperCase()}</div>

            <div className="customer-body">
              <h2 className="customer-name">{item.username}</h2>
              <p className="customer-comment line-clamp-2">{item.latestComment || "Chưa có comment"}</p>

              <div className="customer-meta-row">
                <span className="customer-meta">{item.totalComments} comment</span>
                <span className="customer-meta">{item.totalOrders} đơn</span>
              </div>
            </div>
          </article>
        ))
      )}
    </div>
  );
}
