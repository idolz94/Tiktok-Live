"use client";

import { Order } from "../../../types";

export default function ShippingView({ orders }: { orders: Order[] }) {
  return (
    <div className="list-content scroll-panel">
      <div className="page-header">
        <h1 className="page-title">Vận đơn</h1>
        <p className="page-subtitle">Danh sách đơn chờ tạo vận đơn Viettel Post / đơn vị vận chuyển</p>
      </div>

      {orders.length === 0 ? (
        <div className="empty">
          <p className="empty-text">Chưa có đơn để tạo vận đơn.</p>
        </div>
      ) : (
        orders.map((item) => (
          <article key={item.id} className="shipping-card">
            <div className="row-between">
              <strong className="shipping-code">{item.orderCode}</strong>
              <span className="shipping-status">Chờ tạo vận đơn</span>
            </div>

            <h2 className="shipping-customer">{item.username}</h2>
            <p className="shipping-comment">{item.comment}</p>

            <div className="shipping-actions">
              <button className="shipping-button" type="button">Tạo vận đơn</button>
              <button className="shipping-ghost-button" type="button">Chi tiết</button>
            </div>
          </article>
        ))
      )}
    </div>
  );
}
