"use client";

import { useEffect, useMemo, useState } from "react";
import { formatDate, formatDuration } from "@/utils/comment";
import LiveStatusPill from "../../../components/LiveStatusPill";
import { formatTime } from "@/utils/date";

type LiveSession = {
  sessionId?: string;
  id?: string;
  username: string;
  startedAt: string;
  endedAt?: string | null;
  durationSeconds?: number;
  commentCount?: number;
};

export default function SessionHeader({
  isConnected,
  status,
  tiktokUsername,
  currentLiveSession,
}: {
  isConnected: boolean;
  status: string;
  tiktokUsername: string;
  currentLiveSession: LiveSession | null;
}) {
  const [now, setNow] = useState(Date.now());

  const isRunning =
    Boolean(currentLiveSession?.startedAt) && !currentLiveSession?.endedAt;

  useEffect(() => {
    if (!isRunning) return;

    const timer = setInterval(() => {
      setNow(Date.now());
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, currentLiveSession?.sessionId, currentLiveSession?.startedAt]);

  const duration = useMemo(() => {
    if (!currentLiveSession?.startedAt) return 0;

    if (currentLiveSession.endedAt) {
      return currentLiveSession.durationSeconds || 0;
    }

    const start = new Date(currentLiveSession.startedAt).getTime();

    if (!start) return 0;

    return Math.max(0, Math.floor((now - start) / 1000));
  }, [currentLiveSession, now]);

  const startTime = currentLiveSession?.startedAt
    ? formatTime(currentLiveSession.startedAt)
    : "";

  const endTime = currentLiveSession?.endedAt
    ? formatTime(currentLiveSession.endedAt)
    : isRunning
      ? formatTime(new Date(now).toISOString())
      : "";

  return (
    <header className="session-header">
      <div className="title-row">
        <button className="back-btn" type="button">‹</button>
        <h1 className="screen-title">Chi tiết phiên LIVE</h1>
        <div className="back-btn" />
      </div>

      <div className="session-info">
        {currentLiveSession?.startedAt ? (
          <p className="text-lg font-bold text-gray-800">
            ▣ phiên {formatDate(currentLiveSession.startedAt)} {startTime} - {endTime}
            {" "}
            <span className="text-gray-400">
              ({formatDuration(duration)})
            </span>
          </p>
        ) : (
          <p className="text-lg font-bold text-gray-800">
            ▣ Đang chờ comment đầu tiên...
          </p>
        )}

        <p className="username-line">☻ {tiktokUsername}</p>
      </div>

      <LiveStatusPill isConnected={isConnected} status={status} />
    </header>
  );
}