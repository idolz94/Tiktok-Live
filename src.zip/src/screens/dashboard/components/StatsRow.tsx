"use client";

export default function StatsRow({
  commentsCount,
  buyingCount,
  ordersCount,
}: {
  commentsCount: number;
  buyingCount: number;
  ordersCount: number;
}) {
  return (
    <div className="stats-row">
      <div className="stat-card">
        <strong className="stat-number">{commentsCount}</strong>
        <span className="stat-label">Comment</span>
      </div>

      <div className="stat-card">
        <strong className="stat-number">{buyingCount}</strong>
        <span className="stat-label">Có thể chốt</span>
      </div>

      <div className="stat-card">
        <strong className="stat-number">{ordersCount}</strong>
        <span className="stat-label">Đơn</span>
      </div>
    </div>
  );
}
