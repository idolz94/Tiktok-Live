"use client";

export default function SectionHeader({
  title,
  actionText,
  onAction,
}: {
  title: string;
  actionText?: string;
  onAction?: () => void;
}) {
  return (
    <div className="section-header">
      <h2 className="section-title">{title}</h2>
      {actionText && onAction ? (
        <button className="clear-text" onClick={onAction} type="button">{actionText}</button>
      ) : null}
    </div>
  );
}
