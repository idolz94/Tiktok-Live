"use client";

import { useState } from "react";
import ProductTable from "../components/ProductTable";
import { Order } from "../types";
import { formatMoneyFromK, getOrderTotal } from "../utils/order";

function buildOrderHtml(order: Order) {
  const products = order.products || [];
  const productTotal = getOrderTotal(products);
  const shippingFee = 0;
  const prepaid = 0;
  const remain = productTotal + shippingFee - prepaid;

  const productRows = products
    .map((item, index) => {
      const total = Number(item.price || 0) * Number(item.quantity || 0);

      return `
        <tr>
          <td>${index + 1}</td>
          <td>${item.code}</td>
          <td>${item.price}.000đ × ${item.quantity}</td>
          <td>${formatMoneyFromK(total)}</td>
        </tr>
      `;
    })
    .join("");

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${order.orderCode}</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, Arial, sans-serif; padding: 18px; color: #111827; }
          .center { text-align: center; }
          .title { font-size: 22px; font-weight: 800; margin-bottom: 4px; }
          .subtitle { font-size: 14px; color: #6b7280; margin-bottom: 18px; }
          .info { font-size: 14px; line-height: 22px; margin-bottom: 16px; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; margin-bottom: 16px; }
          th { background: #f3f4f6; font-size: 14px; padding: 10px 6px; border: 1px solid #d1d5db; text-align: left; }
          td { font-size: 14px; padding: 10px 6px; border: 1px solid #d1d5db; }
          .summary { margin-top: 18px; font-size: 15px; line-height: 26px; }
          .summary-row { display: flex; justify-content: space-between; }
          .total { margin-top: 10px; padding-top: 10px; border-top: 1px solid #d1d5db; font-size: 18px; font-weight: 800; }
          .footer { margin-top: 24px; text-align: center; font-size: 13px; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="center">
          <div class="title">HOÁ ĐƠN BÁN HÀNG</div>
          <div class="subtitle">Flive - TikTok LIVE</div>
        </div>
        <div class="info">
          <div><b>Mã đơn:</b> ${order.orderCode}</div>
          <div><b>Khách hàng:</b> ${order.username}</div>
          <div><b>Comment:</b> ${order.comment}</div>
          <div><b>Ngày tạo:</b> ${new Date(order.createdAt).toLocaleString("vi-VN")}</div>
        </div>
        <table>
          <thead>
            <tr><th>#</th><th>Sản phẩm</th><th>Giá × SL</th><th>Tổng</th></tr>
          </thead>
          <tbody>${productRows}</tbody>
        </table>
        <div class="summary">
          <div class="summary-row"><span>Tạm tính</span><b>${formatMoneyFromK(productTotal)}</b></div>
          <div class="summary-row"><span>Phí vận chuyển</span><b>${formatMoneyFromK(shippingFee)}</b></div>
          <div class="summary-row"><span>Trả trước</span><b>- ${formatMoneyFromK(prepaid)}</b></div>
          <div class="summary-row total"><span>Còn lại</span><span>${formatMoneyFromK(remain)}</span></div>
        </div>
        <div class="footer">Cảm ơn quý khách!</div>
      </body>
    </html>
  `;
}

export default function OrderOverviewScreen({
  order,
  onBack,
  onConfirm,
}: {
  order: Order;
  onBack: () => void;
  onConfirm: (orderId: string) => void;
}) {
  const [showPrinterModal, setShowPrinterModal] = useState(false);

  const productTotal = getOrderTotal(order.products || []);
  const shippingFee = 0;
  const prepaid = 0;
  const remain = productTotal + shippingFee - prepaid;

  function connectPrinter() {
    setShowPrinterModal(false);
    window.alert("Kết nối máy in\nBước tiếp theo cần tích hợp máy in thật: AirPrint/WiFi hoặc máy in nhiệt Bluetooth.");
  }

  function handlePrint() {
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) {
      setShowPrinterModal(true);
      return;
    }

    printWindow.document.open();
    printWindow.document.write(buildOrderHtml(order));
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  }

  async function handleShare() {
    const text = `${order.orderCode}\nKhách: ${order.username}\nTổng: ${formatMoneyFromK(remain)}`;

    if (navigator.share) {
      await navigator.share({ title: order.orderCode, text });
      return;
    }

    await navigator.clipboard?.writeText(text);
    window.alert("Đã copy thông tin hoá đơn vào clipboard");
  }

  function handleShip() {
    window.alert("Tạo vận đơn\nBạn có thể tích hợp Viettel Post API ở bước tiếp theo.");
  }

  return (
    <main className="overview-safe">
      <header className="overview-header">
        <div className="overview-title-row">
          <button className="overview-back-btn" onClick={onBack} type="button">‹</button>

          <div className="overview-title-box">
            <h1 className="overview-title">Tổng quan đơn hàng</h1>
            <span className="overview-subtitle">Flive</span>
          </div>

          <button className="overview-setting-btn" onClick={() => setShowPrinterModal(true)} type="button">⚙</button>
        </div>

        <div className="customer-block">
          <h2 className="overview-customer-name">{order.username}</h2>
          <span className="overview-vip-badge">VIP</span>
          <p className="overview-info-line">♧ 0949179149 (VinaPhone)</p>
          <p className="overview-info-line">⌖ Số 10 trường thi tp vinh nghệ an, Phường Trường Thi, Thành Phố Vinh, Tỉnh Nghệ An</p>
        </div>
      </header>

      <div className="overview-body scroll-panel">
        <section className="overview-section">
          <ProductTable products={order.products || []} />
        </section>

        <section className="summary-section">
          <h2 className="overview-section-title">Tóm tắt đơn hàng</h2>

          <div className="summary-row">
            <span>Phí vận chuyển</span>
            <div className="amount-box">{formatMoneyFromK(shippingFee)}</div>
          </div>

          <div className="summary-row">
            <span>Trả trước</span>
            <div className="prepaid-wrap"><strong>-</strong><div className="amount-box">{formatMoneyFromK(prepaid)}</div></div>
          </div>

          <div className="thin-divider" />

          <div className="remain-row">
            <strong>Còn lại</strong>
            <strong>{formatMoneyFromK(remain)}</strong>
          </div>
        </section>

        <section className="overview-action-section">
          <div className="overview-action-row">
            <button className="yellow-btn" onClick={handlePrint} type="button">▣ IN ĐƠN</button>
            <button className={`yellow-btn ${order.status === "confirmed" ? "green" : ""}`} onClick={() => onConfirm(order.id)} type="button">
              {order.status === "confirmed" ? "✓ ĐÃ CHỐT" : "✓ CHỐT ĐƠN"}
            </button>
          </div>

          <button className="share-btn" onClick={handleShare} type="button">⇧ CHIA SẺ HOÁ ĐƠN</button>
        </section>

        <section className="ship-section">
          <div className="carrier-box">
            <span className="vtp-icon">▣</span>
            <span className="carrier-text">VTP - Viettel Post</span>
            <span className="chevron">⌄</span>
          </div>

          <button className="ship-btn" onClick={handleShip} type="button">SHIP 🚚</button>
        </section>
      </div>

      {showPrinterModal && (
        <div className="modal-overlay" role="dialog" aria-modal="true">
          <div className="modal-card">
            <div className="modal-icon-wrap">🖨️</div>
            <h2 className="modal-title">Chưa kết nối với máy in</h2>
            <p className="modal-desc">Bạn chưa kết nối với máy in nào, hãy kết nối ngay để in ra phiếu giấy.</p>

            <button className="connect-printer-btn" onClick={connectPrinter} type="button">KẾT NỐI NGAY</button>
            <button className="cancel-btn" onClick={() => setShowPrinterModal(false)} type="button">Để sau</button>
          </div>
        </div>
      )}
    </main>
  );
}
