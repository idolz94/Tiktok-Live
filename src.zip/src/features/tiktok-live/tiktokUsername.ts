export function normalizeTikTokUsername(value: string) {
  const cleanValue = String(value || "").trim();

  if (!cleanValue) return "";

  return cleanValue.startsWith("@") ? cleanValue : `@${cleanValue}`;
}
