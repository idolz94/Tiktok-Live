import { LIVE_HISTORY_KEY, MAX_LIVE_HISTORY_ITEMS } from "./constants";
import type { LiveHistoryItem } from "./types";

export function readLiveHistory(): LiveHistoryItem[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = localStorage.getItem(LIVE_HISTORY_KEY);
    const parsed = JSON.parse(raw || "[]");

    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function writeLiveHistory(data: LiveHistoryItem[]) {
  if (typeof window === "undefined") return;

  localStorage.setItem(LIVE_HISTORY_KEY, JSON.stringify(data));
}

export function saveHistoryItem(item: LiveHistoryItem) {
  const oldHistory = readLiveHistory();

  const existed = oldHistory.find(
    (history) => history.sessionId === item.sessionId
  );

  const comments = item.comments.length > 0 ? item.comments : existed?.comments || [];

  const fixedItem: LiveHistoryItem = {
    ...item,
    comments,
    commentCount: Math.max(item.commentCount || 0, comments.length),
  };

  const nextHistory = [
    fixedItem,
    ...oldHistory.filter((history) => history.sessionId !== item.sessionId),
  ].slice(0, MAX_LIVE_HISTORY_ITEMS);

  writeLiveHistory(nextHistory);

  return nextHistory;
}

export function clearLiveHistoryStorage() {
  writeLiveHistory([]);
}
