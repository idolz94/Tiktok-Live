import { useEffect } from "react";

export function useBrowserCloseSession(onClose: () => void) {
  useEffect(() => {
    const saveBeforeClose = () => {
      onClose();
    };

    window.addEventListener("pagehide", saveBeforeClose);
    window.addEventListener("beforeunload", saveBeforeClose);

    return () => {
      window.removeEventListener("pagehide", saveBeforeClose);
      window.removeEventListener("beforeunload", saveBeforeClose);
    };
  }, [onClose]);
}
