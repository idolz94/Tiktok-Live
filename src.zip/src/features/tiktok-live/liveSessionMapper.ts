import { calcDurationSeconds } from "@/utils/date";
import type { LiveHistoryItem } from "./types";
import { createId } from "@/utils/id";

export function normalizeLiveSession(payload: any): LiveHistoryItem {
  const sessionId = String(
    payload?.sessionId || payload?.session_id || payload?.id || createId()
  );

  const startedAt = String(
    payload?.startedAt || payload?.started_at || new Date().toISOString()
  );

  const endedAt = payload?.endedAt || payload?.ended_at || null;

  return {
    id: sessionId,
    sessionId,
    username: String(payload?.username || payload?.tiktokUsername || ""),
    startedAt,
    endedAt,
    durationSeconds: Number(
      payload?.durationSeconds ||
        payload?.duration_seconds ||
        (endedAt ? calcDurationSeconds(startedAt, endedAt) : 0)
    ),
    commentCount: Number(payload?.commentCount || payload?.comment_count || 0),
    reason: payload?.reason,
    comments: Array.isArray(payload?.comments) ? payload.comments : [],
  };
}
