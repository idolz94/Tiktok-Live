import { useEffect, useState } from "react";
import type { LiveHistoryItem } from "./types";

export function useLiveDuration(currentLiveSession: LiveHistoryItem | null) {
  const [liveDurationSeconds, setLiveDurationSeconds] = useState(0);
  const [liveNowText, setLiveNowText] = useState("");

  useEffect(() => {
    if (!currentLiveSession?.startedAt || currentLiveSession.endedAt) {
      setLiveDurationSeconds(currentLiveSession?.durationSeconds || 0);
      return;
    }

    const updateDuration = () => {
      const start = new Date(currentLiveSession.startedAt).getTime();
      const now = Date.now();

      if (!start) return;

      setLiveDurationSeconds(Math.max(0, Math.floor((now - start) / 1000)));

      setLiveNowText(
        new Date().toLocaleTimeString("vi-VN", {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
    };

    updateDuration();

    const timer = setInterval(updateDuration, 1000);

    return () => clearInterval(timer);
  }, [currentLiveSession]);

  return {
    liveDurationSeconds,
    liveNowText,
  };
}
