"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  DEFAULT_WS_URL,
  MAX_COMMENTS,
  RECONNECT_DELAY,
  TIKTOK_USERNAME,
} from "@/constants/config";
import type { LiveComment, SocketMessage } from "@/types";
import { normalizeComment } from "@/utils/comment";
import {
  clearLiveHistoryStorage,
  readLiveHistory,
  saveHistoryItem,
} from "@/features/tiktok-live/liveHistoryStorage";
import { normalizeLiveSession } from "@/features/tiktok-live/liveSessionMapper";
import { normalizeTikTokUsername } from "@/features/tiktok-live/tiktokUsername";
import { useBrowserCloseSession } from "@/features/tiktok-live/useBrowserCloseSession";
import { useLiveDuration } from "@/features/tiktok-live/useLiveDuration";
import type { LiveHistoryItem } from "@/features/tiktok-live/types";
import { calcDurationSeconds } from "@/utils/date";

export function useTikTokLiveSocket() {
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const shouldReconnectRef = useRef(true);
  const isManualCloseRef = useRef(false);

  const tiktokUsernameRef = useRef(normalizeTikTokUsername(TIKTOK_USERNAME));

  const currentSessionRef = useRef<LiveHistoryItem | null>(null);
  const sessionCommentsRef = useRef<LiveComment[]>([]);

  const [status, setStatus] = useState("Đang kết nối...");
  const [isConnected, setIsConnected] = useState(false);
  const [comments, setComments] = useState<LiveComment[]>([]);
  const [tiktokUsername, setTikTokUsername] = useState(
    normalizeTikTokUsername(TIKTOK_USERNAME)
  );

  const [currentLiveSession, setCurrentLiveSession] =
    useState<LiveHistoryItem | null>(null);

  const [liveHistory, setLiveHistory] = useState<LiveHistoryItem[]>([]);

  const { liveDurationSeconds, liveNowText } = useLiveDuration(currentLiveSession);

  useEffect(() => {
    setLiveHistory(readLiveHistory());
  }, []);

  const finalizeCurrentSessionLocally = useCallback((reason: string) => {
    const session = currentSessionRef.current;

    if (!session?.startedAt) return;

    const endedAt = new Date().toISOString();
    const commentsOfSession = sessionCommentsRef.current;

    const historyItem: LiveHistoryItem = {
      ...session,
      endedAt,
      durationSeconds: calcDurationSeconds(session.startedAt, endedAt),
      commentCount: commentsOfSession.length,
      comments: commentsOfSession,
      reason,
    };

    const nextHistory = saveHistoryItem(historyItem);

    setLiveHistory(nextHistory);
    setCurrentLiveSession(null);

    currentSessionRef.current = null;
    sessionCommentsRef.current = [];
  }, []);

  useBrowserCloseSession(() => {
    finalizeCurrentSessionLocally("browser_close");
  });

  const addComment = useCallback((rawComment: any) => {
    const comment = normalizeComment(rawComment);

    if (!comment) return;

    setComments((prev) => {
      const existed = prev.some((item) => item.id === comment.id);
      if (existed) return prev;

      return [comment, ...prev].slice(0, MAX_COMMENTS);
    });

    const session = currentSessionRef.current;

    if (!session) return;

    const existed = sessionCommentsRef.current.some(
      (item) => item.id === comment.id
    );

    if (!existed) {
      sessionCommentsRef.current = [
        comment,
        ...sessionCommentsRef.current,
      ].slice(0, MAX_COMMENTS);
    }

    const nextSession: LiveHistoryItem = {
      ...session,
      commentCount: sessionCommentsRef.current.length,
      comments: sessionCommentsRef.current,
    };

    currentSessionRef.current = nextSession;
    setCurrentLiveSession(nextSession);
  }, []);

  const replaceSnapshot = useCallback((rawComments: any[]) => {
    const normalized = rawComments
      .map(normalizeComment)
      .filter((item): item is LiveComment => Boolean(item));

    setComments(normalized.slice(0, MAX_COMMENTS));
  }, []);

  const sendJson = useCallback(
    (type: string, payload: Record<string, any> = {}) => {
      const socket = socketRef.current;

      if (!socket || socket.readyState !== WebSocket.OPEN) {
        return false;
      }

      socket.send(
        JSON.stringify({
          type,
          payload,
        })
      );

      return true;
    },
    []
  );

  const subscribeTikTokUsername = useCallback(
    (username: string) => {
      const nextUsername = normalizeTikTokUsername(username);

      if (!nextUsername) {
        setStatus("Vui lòng nhập TikTok username");
        return false;
      }

      const oldUsername = tiktokUsernameRef.current;

      if (oldUsername && oldUsername !== nextUsername) {
        finalizeCurrentSessionLocally("change_username");
      }

      tiktokUsernameRef.current = nextUsername;
      setTikTokUsername(nextUsername);
      setComments([]);
      setStatus(`Đang subscribe LIVE ${nextUsername}...`);

      const sent = sendJson("SUBSCRIBE_TIKTOK_USERNAME", {
        username: nextUsername,
      });

      if (!sent) {
        setStatus("Chưa kết nối server Python. Sẽ tự subscribe lại khi kết nối.");
      }

      return sent;
    },
    [sendJson, finalizeCurrentSessionLocally]
  );

  const stopLiveSession = useCallback(() => {
    setStatus("Đang dừng nhận comment...");

    sendJson("STOP", {
      username: tiktokUsernameRef.current,
    });

    finalizeCurrentSessionLocally("manual_stop");

    return true;
  }, [sendJson, finalizeCurrentSessionLocally]);

  const handleSocketMessage = useCallback(
    (event: MessageEvent) => {
      try {
        const message = JSON.parse(String(event.data)) as SocketMessage;
        const type = String(message.type || "").toUpperCase();
        const payload = (message as any).payload || (message as any).data || {};

        if (type === "CONNECTED") {
          setStatus("Đã kết nối server Python");
          setIsConnected(true);
          return;
        }

        if (type === "SUBSCRIBING") {
          setStatus(`Đang chuẩn bị lấy comment LIVE: ${payload.username || ""}`);
          return;
        }

        if (type === "SUBSCRIBED") {
          const username = payload.username || payload.tiktokUsername || "";

          if (username) {
            tiktokUsernameRef.current = username;
            setTikTokUsername(username);
          }

          const snapshot = payload.comments || [];
          replaceSnapshot(Array.isArray(snapshot) ? snapshot : []);

          setStatus(`Đã subscribe LIVE ${username}, đang chờ comment đầu tiên...`);
          return;
        }

        if (type === "LIVE_TIME_STARTED") {
          const session = normalizeLiveSession(payload);

          currentSessionRef.current = session;
          sessionCommentsRef.current = [];

          setCurrentLiveSession(session);
          setStatus(`Bắt đầu phiên nhận comment: ${session.username}`);
          return;
        }

        if (type === "LIVE_TIME_ENDED") {
          const sessionFromPython = normalizeLiveSession(payload);

          const commentsOfSession =
            currentSessionRef.current?.sessionId === sessionFromPython.sessionId
              ? sessionCommentsRef.current
              : [];

          const historyItem: LiveHistoryItem = {
            ...sessionFromPython,
            comments: commentsOfSession,
            commentCount: Math.max(
              sessionFromPython.commentCount,
              commentsOfSession.length
            ),
          };

          const nextHistory = saveHistoryItem(historyItem);

          setLiveHistory(nextHistory);
          setCurrentLiveSession(null);

          if (currentSessionRef.current?.sessionId === sessionFromPython.sessionId) {
            currentSessionRef.current = null;
            sessionCommentsRef.current = [];
          }

          setStatus(`Đã lưu phiên LIVE: ${sessionFromPython.username}`);
          return;
        }

        if (type === "LIVE_TIME_STATUS") {
          if (!payload || !payload.startedAt) {
            currentSessionRef.current = null;
            sessionCommentsRef.current = [];
            setCurrentLiveSession(null);
            return;
          }

          const session = normalizeLiveSession(payload);

          currentSessionRef.current = session;
          setCurrentLiveSession(session);
          return;
        }

        if (type === "UNSUBSCRIBED") {
          finalizeCurrentSessionLocally("unsubscribed");
          setComments([]);
          setStatus(`Đã rời LIVE: ${payload.username || ""}`);
          return;
        }

        if (type === "LIVE_CONNECTED") {
          setStatus(`Đã kết nối TikTok Live: ${payload.username || ""}`);
          return;
        }

        if (type === "LIVE_DISCONNECTED") {
          finalizeCurrentSessionLocally("live_disconnected");
          setStatus(`TikTok Live đã ngắt: ${payload.username || ""}`);
          return;
        }

        if (type === "LIVE_ERROR") {
          finalizeCurrentSessionLocally("live_error");
          setStatus(
            `TikTok lỗi ${payload.username || ""}: ${
              payload.message || "Không rõ lỗi"
            }`
          );
          return;
        }

        if (type === "SNAPSHOT") {
          const snapshot = payload.comments || [];
          replaceSnapshot(Array.isArray(snapshot) ? snapshot : []);
          return;
        }

        if (type === "COMMENT") {
          addComment(payload);
          return;
        }

        console.log("Message type chưa xử lý:", message);
      } catch (error) {
        console.log("Không parse được message:", error);
      }
    },
    [addComment, replaceSnapshot, finalizeCurrentSessionLocally]
  );

  const clearReconnectTimer = useCallback(() => {
    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
  }, []);

  const connectSocket = useCallback(() => {
    const url = DEFAULT_WS_URL.trim();

    if (!url) {
      setStatus("Thiếu WebSocket URL");
      return;
    }

    const currentSocket = socketRef.current;

    if (
      currentSocket &&
      (currentSocket.readyState === WebSocket.OPEN ||
        currentSocket.readyState === WebSocket.CONNECTING)
    ) {
      return;
    }

    clearReconnectTimer();

    try {
      setStatus("Đang kết nối server Python...");
      setIsConnected(false);

      const socket = new WebSocket(url);
      socketRef.current = socket;

      socket.onopen = () => {
        setStatus("Đã kết nối server Python");
        setIsConnected(true);

        const username = tiktokUsernameRef.current;

        if (username) {
          socket.send(
            JSON.stringify({
              type: "SUBSCRIBE_TIKTOK_USERNAME",
              payload: {
                username,
              },
            })
          );
        }
      };

      socket.onmessage = handleSocketMessage;

      socket.onerror = (error) => {
        console.log("WS ERROR:", error);
        setStatus("Lỗi WebSocket");
        setIsConnected(false);
      };

      socket.onclose = () => {
        finalizeCurrentSessionLocally("socket_close");
        setIsConnected(false);
        socketRef.current = null;

        if (isManualCloseRef.current || !shouldReconnectRef.current) {
          setStatus("Đã ngắt kết nối");
          return;
        }

        setStatus("Mất kết nối, đang tự kết nối lại...");

        reconnectTimerRef.current = setTimeout(() => {
          connectSocket();
        }, RECONNECT_DELAY);
      };
    } catch (error) {
      console.log("CONNECT ERROR:", error);
      setStatus("Lỗi kết nối WebSocket");
      setIsConnected(false);

      reconnectTimerRef.current = setTimeout(() => {
        connectSocket();
      }, RECONNECT_DELAY);
    }
  }, [clearReconnectTimer, handleSocketMessage, finalizeCurrentSessionLocally]);

  const reconnect = useCallback(() => {
    finalizeCurrentSessionLocally("manual_reconnect");

    shouldReconnectRef.current = true;
    isManualCloseRef.current = false;

    socketRef.current?.close();
    socketRef.current = null;

    connectSocket();
  }, [connectSocket, finalizeCurrentSessionLocally]);

  const disconnect = useCallback(() => {
    finalizeCurrentSessionLocally("manual_disconnect");

    shouldReconnectRef.current = false;
    isManualCloseRef.current = true;

    clearReconnectTimer();

    sendJson("STOP", {
      username: tiktokUsernameRef.current,
    });

    socketRef.current?.close();
    socketRef.current = null;

    setIsConnected(false);
    setStatus("Đã ngắt kết nối");
  }, [clearReconnectTimer, sendJson, finalizeCurrentSessionLocally]);

  const clearComments = useCallback(() => {
    setComments([]);
  }, []);

  const clearLiveHistory = useCallback(() => {
    setLiveHistory([]);
    clearLiveHistoryStorage();
  }, []);

  useEffect(() => {
    shouldReconnectRef.current = true;
    isManualCloseRef.current = false;

    connectSocket();

    return () => {
      finalizeCurrentSessionLocally("component_unmount");

      shouldReconnectRef.current = false;
      isManualCloseRef.current = true;

      clearReconnectTimer();

      sendJson("STOP", {
        username: tiktokUsernameRef.current,
      });

      socketRef.current?.close();
    };
  }, [
    clearReconnectTimer,
    connectSocket,
    sendJson,
    finalizeCurrentSessionLocally,
  ]);

  return {
    status,
    isConnected,
    comments,
    tiktokUsername,

    currentLiveSession,
    liveHistory,
    liveDurationSeconds,
    liveNowText,

    setComments,
    clearComments,
    clearLiveHistory,

    reconnect,
    disconnect,
    stopLiveSession,

    changeTikTokUsername: subscribeTikTokUsername,
    subscribeTikTokUsername,
  };
}
