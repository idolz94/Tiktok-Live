"use client";

import { OrderFilter } from "../types";

type FilterItem = {
  key: OrderFilter;
  label: string;
  value: number;
};

export default function OrderFilterBar({
  searchText,
  onChangeSearch,
  activeFilter,
  onChangeFilter,
  productCount,
  unpaidCount,
  paidCount,
  draftCount,
  confirmedCount,
}: {
  searchText: string;
  onChangeSearch: (value: string) => void;
  activeFilter: OrderFilter;
  onChangeFilter: (value: OrderFilter) => void;
  productCount: number;
  unpaidCount: number;
  paidCount: number;
  draftCount: number;
  confirmedCount: number;
}) {
  const filters: FilterItem[] = [
    { key: "unpaid", label: "Chưa Cọc", value: unpaidCount },
    { key: "paid", label: "Đã Cọc", value: paidCount },
    { key: "draft", label: "Đơn Nháp", value: draftCount },
    { key: "confirmed", label: "Đã Chốt", value: confirmedCount },
  ];

  return (
    <div className="order-filter-bar">
      <div className="search-line">
        <div className="search-box">
          <span className="search-icon">⌕</span>

          <input
            value={searchText}
            onChange={(event) => onChangeSearch(event.target.value)}
            placeholder="Tìm kiếm"
            className="search-input"
          />
        </div>

        <div className="product-count-box">
          <span className="product-count-label">Sản Phẩm</span>
          <strong className="product-count-number">{productCount}</strong>
        </div>
      </div>

      <div className="filter-row">
        <button
          className={`filter-icon-box ${activeFilter === "all" ? "active" : ""}`}
          onClick={() => onChangeFilter("all")}
          type="button"
        >
          <span className="filter-label">Bộ Lọc</span>
          <span className="filter-icon">▼</span>
        </button>

        {filters.map((item) => {
          const isActive = activeFilter === item.key;

          return (
            <button
              key={item.key}
              className={`filter-chip ${isActive ? "active" : ""}`}
              onClick={() => onChangeFilter(item.key)}
              type="button"
            >
              <span className="filter-chip-label">{item.label}</span>
              <strong className="filter-chip-number">{item.value}</strong>
            </button>
          );
        })}
      </div>
    </div>
  );
}
