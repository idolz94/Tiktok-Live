"use client";

import { OrderProduct } from "../types";
import { formatMoneyFromK, getOrderTotal, getProductTotal } from "../utils/order";

export default function ProductTable({
  products,
  onAddProduct,
}: {
  products: OrderProduct[];
  onAddProduct?: () => void;
}) {
  const total = getOrderTotal(products);

  return (
    <div className="product-table-wrap">
      <div className="product-table-header-row">
        <h3 className="product-table-title">Danh sách sản phẩm</h3>

        {onAddProduct && (
          <button className="add-product-btn" onClick={onAddProduct} type="button" aria-label="Thêm sản phẩm">
            ＋
          </button>
        )}
      </div>

      <div className="product-table">
        <div className="product-row product-header">
          <div className="product-cell index">#</div>
          <div className="product-cell code">Mã</div>
          <div className="product-cell price">Giá × SL</div>
          <div className="product-cell total">Tổng</div>
        </div>

        {products.map((product, index) => {
          const productTotal = getProductTotal(product);

          return (
            <div key={product.id} className="product-row">
              <div className="product-cell index">{index + 1}.</div>
              <div className="product-cell code truncate">{product.code}</div>
              <div className="product-cell price highlight">
                {product.price} × {product.quantity}
              </div>
              <div className="product-cell total">{formatMoneyFromK(productTotal)}</div>
            </div>
          );
        })}
      </div>

      <p className="product-total-text">
        {products.length} sản phẩm, tổng cộng <strong>{formatMoneyFromK(total)}</strong>
      </p>
    </div>
  );
}
