"use client";

import { BottomTab } from "../types";

const ITEMS: { key: BottomTab; icon: string; label: string }[] = [
  { key: "home", icon: "⌂", label: "Trang chủ" },
  { key: "customers", icon: "👥", label: "Khách hàng" },
  { key: "shipping", icon: "🚚", label: "Vận đơn" },
  { key: "reports", icon: "▣", label: "Báo cáo" },
  { key: "settings", icon: "⚙", label: "Cài đặt" },
];

export default function BottomNav({
  active,
  onChange,
}: {
  active: BottomTab;
  onChange: (tab: BottomTab) => void;
}) {
  return (
    <nav className="bottom-nav">
      {ITEMS.map((item) => {
        const isActive = item.key === active;

        return (
          <button key={item.key} className="bottom-nav-item" onClick={() => onChange(item.key)} type="button">
            <span className={`bottom-nav-icon ${isActive ? "active" : ""}`}>{item.icon}</span>
            <span className={`bottom-nav-label ${isActive ? "active" : ""}`}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
