"use client";

export default function LiveStatusPill({
  isConnected,
  status,
}: {
  isConnected: boolean;
  status: string;
}) {
  return (
    <div className="live-status-pill">
      <span className={`live-status-dot ${isConnected ? "online" : "offline"}`} />
      <span className={`live-status-text ${isConnected ? "online" : "offline"}`}>{status}</span>
    </div>
  );
}
