"use client";

export default function Avatar({
  uri,
  username,
  size = 42,
}: {
  uri?: string;
  username: string;
  size?: number;
}) {
  const firstChar = username?.trim()?.charAt(0)?.toUpperCase() || "?";

  if (uri) {
    return (
      <img
        src={uri}
        alt={username}
        className="avatar-img"
        style={{ width: size, height: size, borderRadius: size / 2 }}
      />
    );
  }

  return (
    <div
      className="avatar-fallback"
      style={{ width: size, height: size, borderRadius: size / 2 }}
    >
      {firstChar}
    </div>
  );
}
