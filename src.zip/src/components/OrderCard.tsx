"use client";

import { Order, OrderProduct } from "../types";
import { createProductFromComment, formatMoneyFromK, getOrderTotal } from "../utils/order";
import Avatar from "./Avatar";
import ProductTable from "./ProductTable";

function createDisplayCode(orderCode: string) {
  const numbers = orderCode.replace(/\D/g, "");
  return `#${(numbers || orderCode).slice(-6).padStart(6, "0")}`;
}

export default function OrderCard({
  item,
  onUpdate,
  onDelete,
  onAddProduct,
  onToggleDeposit,
  onConfirmOrder,
  onOpenOverview,
}: {
  item: Order;
  onUpdate: (id: string, field: keyof Order, value: string) => void;
  onDelete: (id: string) => void;
  onAddProduct?: (orderId: string, product: OrderProduct) => void;
  onToggleDeposit?: (orderId: string) => void;
  onConfirmOrder?: (orderId: string) => void;
  onOpenOverview?: (orderId: string) => void;
}) {
  const total = getOrderTotal(item.products || []);
  const isPaid = item.depositStatus === "paid";
  const isConfirmed = item.status === "confirmed";

  return (
    <article className="order-card">
      <div className="order-top-row">
        <Avatar uri={item.avatar} username={item.username} size={58} />

        <div className="customer-info">
          <strong className="order-code">{createDisplayCode(item.orderCode)}</strong>
          <h3 className="order-username">{item.username || "Unknown user"}</h3>

          <div className="badge-row">
            <span className="vip-badge">VIP</span>
            <span className="icon-badge">⌖</span>
            <span className="icon-badge">☎</span>
          </div>
        </div>

        <div className="right-actions">
          <span className={`status-badge ${isConfirmed ? "confirmed" : ""}`}>
            {isConfirmed ? "Đã Chốt" : "⊖ Đơn Nháp"}
          </span>

          <div className="icon-action-row">
            <button className="icon-button" onClick={() => onDelete(item.id)} type="button">🗑</button>
            <button className="icon-button" type="button">▣</button>
          </div>
        </div>
      </div>

      <div className="order-comment-row">
        <div className="flex-1">
          <p className="order-comment-text">{item.comment}</p>
          <span className="order-time-text">
            {new Date(item.createdAt).toLocaleTimeString("vi-VN", {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            })}
          </span>
        </div>

        <div className="small-actions">
          <span>🗑</span>
          <span className="separator">│</span>
          <span>▣</span>
        </div>
      </div>

      <div className="thin-divider" />

      <div className="estimate-row">
        <div>
          <span className="estimate-label">Tạm tính</span>
          <strong className="estimate-value">{formatMoneyFromK(total)}</strong>
        </div>

        <span className="note-text">Thêm ghi chú ✎</span>
      </div>

      <ProductTable
        products={item.products || []}
        onAddProduct={
          onAddProduct
            ? () => onAddProduct(item.id, createProductFromComment(item.comment))
            : undefined
        }
      />

      <div className="form-grid">
        <label className="field-large">
          <span className="form-label">Tên đơn / sản phẩm</span>
          <input
            value={item.productName}
            onChange={(event) => onUpdate(item.id, "productName", event.target.value)}
            placeholder="Tên sản phẩm"
            className="form-input"
          />
        </label>
      </div>

      <div className="order-action-row">
        <button
          className={`deposit-button ${isPaid ? "paid" : ""}`}
          onClick={() => onToggleDeposit?.(item.id)}
          type="button"
        >
          {isPaid ? "ĐÃ CỌC" : "CHƯA CỌC"}
        </button>

        <button
          className={`total-button ${isConfirmed ? "confirmed" : ""}`}
          onClick={() => onOpenOverview?.(item.id)}
          type="button"
        >
          TỔNG ĐƠN
        </button>
      </div>

      {onConfirmOrder ? null : null}
    </article>
  );
}
