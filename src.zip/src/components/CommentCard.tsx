"use client";

import { LiveComment } from "../types";
import { formatTime } from "../utils/date";
import Avatar from "./Avatar";

export default function CommentCard({
  item,
  onCreateOrder,
}: {
  item: LiveComment;
  onCreateOrder: (item: LiveComment) => void;
}) {
  const isBuying = item.intent === "buying";
  const commentText = item.comment || item.text || "";

  return (
    <article className={`comment-card ${isBuying ? "buying" : ""}`}>
      <Avatar uri={item.avatar} username={item.username} size={46} />

      <div className="comment-card-body">
        <div className="row-between">
          <strong className="comment-username">{item.username || "Unknown user"}</strong>
          <span className={`comment-tag ${isBuying ? "buying" : ""}`}>{isBuying ? "Có thể chốt" : "Thường"}</span>
        </div>

        <p className="comment-text">{commentText}</p>

        <div className="comment-meta-row">
          <span className="comment-time">{formatTime(item.created_at || item.createdAt)}</span>

          <button className="primary-small-btn" onClick={() => onCreateOrder(item)} type="button">
            Tạo đơn
          </button>
        </div>
      </div>
    </article>
  );
}
